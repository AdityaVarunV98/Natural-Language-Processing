- NLP_assignment1.ipynb: Contains the code for data scraping, cleaning and pre-processing, and Exploratory Data Analysis
- title_url_description.txt: Contains the title, url, and a description of each document
- title_url_paragraph.txt: Contains the title, url, and the main textual data of each document
- processed_data.pkl: Pickle file that contains cleaned and pre-processed data used for Exploratory Data Analysis 

Team Members:
- Aditya Varun V (AI22BTECH11001)
- Surya Saketh Chakka (AI22BTECH11005)
- Saketh Ram Kumar Dondapati (AI22BTECH11023)
